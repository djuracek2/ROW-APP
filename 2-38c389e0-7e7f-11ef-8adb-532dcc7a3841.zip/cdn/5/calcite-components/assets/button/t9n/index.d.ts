export type ButtonMessages = {
  loading: string;
};
