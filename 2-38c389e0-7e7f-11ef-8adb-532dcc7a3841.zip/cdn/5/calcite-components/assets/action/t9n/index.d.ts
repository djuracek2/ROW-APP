export type ActionMessages = {
  loading: string;
  indicator: string;
};
